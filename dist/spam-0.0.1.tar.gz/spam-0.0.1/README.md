FAst STatistical LEARNing (fastlearn)


